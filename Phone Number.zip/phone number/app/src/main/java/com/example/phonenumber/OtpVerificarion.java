package com.example.phonenumber;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OtpVerificarion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verificarion);
    }
}
